#!/bin/bash

# Get current profile
current=$(powerprofilesctl get)

# Determine next profile
case "$current" in
    power-saver)
        next="balanced"
        ;;
    balanced)
        next="performance"
        ;;
    performance)
        next="power-saver"
        ;;
    *)
        next="balanced"
        ;;
esac

# Set next profile
powerprofilesctl set "$next"

# Optionally show notification
notify-send "Power Profile" "Switched to $next"

